import os

BOT_TOKEN = os.getenv("BOT_TOKEN", "8865462591:AAHjaL2EeIDfNELG3advRY252ek41WPryOU")
ADMIN_ID = int(os.getenv("ADMIN_ID", "1441524960"))
DB_PATH = os.getenv("DB_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), "alias_group.db"))

STATUS_PENDING = "pending"
STATUS_APPROVED = "approved"
STATUS_REJECTED = "rejected"
STATUS_BANNED = "banned"

ROLE_ADMIN = "admin"
ROLE_MODERATOR = "moderator"
ROLE_MEMBER = "member"

ADMIN_DISPLAY = "المدير"
MOD_DISPLAY_PREFIX = "مشرف"

RESERVED_ALIASES = {
    ADMIN_DISPLAY,
    "مدير",
    "المشرف",
    "مشرف",
    "admin",
    "administrator",
    "mod",
    "moderator",
}

MAX_REAL_NAME = 64
MIN_REAL_NAME = 2
MAX_ALIAS = 32
MIN_ALIAS = 2
MAX_RULES = 3500

DEFAULT_RULES = (
    "قوانين مجموعة عين الشاهين\n"
    "────────\n"
    "1. التسجيل إلزامي عبر البوت في الخاص بالاسم الحقيقي ثم المستعار، ولا يُسمح بالكتابة قبل موافقة المدير.\n"
    "2. يُمنع السؤال عن هويات الأعضاء أو كشفها أو ربط الاسم المستعار بالاسم الحقيقي.\n"
    "3. الأحاديث العامة وذكر أشخاص خارج المجموعة مسموحة ما دامت لا تمس أعضاء المجموعة.\n"
    "4. تظهر الرسائل بالاسم المستعار فقط. المدير يظهر باسم «المدير» والمشرفون «مشرف 1» وهكذا.\n"
    "5. يُمنع انتحال اسم المدير أو المشرفين أو استخدام أسماء مستعارة مسيئة.\n"
    "6. الإفصاح الطوعي عن هويتك يُحذف في المرة الأولى مع تنبيه علني، وفي المرة الثانية تتحمل المسؤولية كاملة.\n"
    "7. مخالفة كشف الهوية: حذف فوري، كتم دقيقة، وتحذير علني أول وأخير قبل الطرد.\n"
    "8. كشف الهوية حق للمدير أو المشرف المصرح له عبر زر ⚡ في الخاص فقط.\n"
    "9. قرارات المدير نهائية في قبول الأعضاء وإدارة الأسماء المستعارة."
)
