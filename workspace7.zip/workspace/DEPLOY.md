# نشر البوت على سيرفر مجاني

البوت يحتاج عملية دائمة (polling). أفضل خيار مجاني ثابت: Oracle Cloud Always Free.

أوقف أي نسخة محلية قبل تشغيل السيرفر حتى لا يحدث تعارض `getUpdates`.

## الملفات الجاهزة

- `.env.example` قالب التوكن ومعرّف المدير
- `deploy/install.sh` تثبيت على Ubuntu مع systemd
- `deploy/aliasbot.service` نموذج الخدمة
- `Dockerfile` و `docker-compose.yml` للتشغيل بالحاوية

## أ) Oracle Cloud + Ubuntu (موصى به)

### 1. إنشاء السيرفر

1. سجّل في https://cloud.oracle.com
2. أنشئ Instance بنظام Ubuntu 22.04
3. الشكل المجاني: `VM.Standard.E2.1.Micro` أو Ampere
4. حمّل مفتاح SSH
5. اسمح بمنفذ 22 في Security List

الاتصال من جهازك:

```bash
ssh -i your-key.key ubuntu@SERVER_IP
```

### 2. رفع المشروع

من جهازك، من مجلد المشروع:

```bash
scp -i your-key.key bot.py config.py database.py security.py utils.py requirements.txt requirements-prod.txt .env.example deploy/install.sh ubuntu@SERVER_IP:/tmp/
```

على السيرفر:

```bash
mkdir -p /home/ubuntu/aliasbot
mv /tmp/bot.py /tmp/config.py /tmp/database.py /tmp/security.py /tmp/utils.py /tmp/requirements.txt /tmp/requirements-prod.txt /tmp/.env.example /tmp/install.sh /home/ubuntu/aliasbot/
chmod +x /home/ubuntu/aliasbot/install.sh
```

### 3. وضع التوكن

```bash
cp /home/ubuntu/aliasbot/.env.example /home/ubuntu/aliasbot/.env
nano /home/ubuntu/aliasbot/.env
```

ضع توكن ‎@BotFather في `BOT_TOKEN`. اترك `ADMIN_ID` كما هو إن كنت المدير.

### 4. التثبيت والتشغيل

```bash
cd /home/ubuntu/aliasbot
./install.sh
```

التحقق:

```bash
sudo systemctl status aliasbot
journalctl -u aliasbot -f
```

أوامر لاحقة:

```bash
sudo systemctl restart aliasbot
sudo systemctl stop aliasbot
```

لنقل البيانات الحالية ارفع أيضاً `alias_group.db` إلى `/home/ubuntu/aliasbot/data/` ثم أعد التشغيل.

## ب) Docker على أي VPS

أنشئ `.env` من `.env.example` ثم:

```bash
docker compose up -d --build
```

السجلات:

```bash
docker compose logs -f
```

قاعدة البيانات تُحفظ في مجلد `data/`.

## بعد التشغيل

1. أوقف النسخة القديمة إن كانت تعمل
2. راسل البوت `/start`
3. اربط المجموعة بـ `/setgroup` داخلها
4. اربط القناة من الخاص بـ `/setchannel`

إذا لم يرد البوت: غالباً نسختان تعملان معاً، أو `BOT_TOKEN` فارغ في `.env`.
