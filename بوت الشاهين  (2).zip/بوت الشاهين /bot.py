import random
import string
import sqlite3
import logging
from datetime import datetime, timedelta
import re

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

# === ضع بياناتك هنا مباشرة ===
BOT_TOKEN = "9196634008:AAEpNftT2s-ZPtlYhQsrx4Gt64FWTm1Lbds"      # مثال: "7123456789:AAF..."
ADMIN_USER_ID = 1441524960              # ضع آيدي حسابك الشخصي (رقم صحيح بدون أقواس)
PUBLIC_GROUP_ID = 0                    # (اختياري) آيدي المجموعة العامة لنشر الرسائل فيها تلقائياً، أو اجعله مثل ADMIN_USER_ID

# إعداد السجلات
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# --- إعداد قاعدة البيانات المحلية SQLite ---
def init_db():
    conn = sqlite3.connect("shahin_bot.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            real_name TEXT,
            alias TEXT,
            status TEXT, -- pending, approved, rejected
            reject_time TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

init_db()

# وظيفة لتوليد اسم مستعار عشوائي فريد وثابت لكل عضو (مثل G5, A9)
def generate_unique_alias():
    conn = sqlite3.connect("shahin_bot.db")
    cursor = conn.cursor()
    while True:
        letter = random.choice(string.ascii_uppercase)
        number = random.randint(10, 99)
        alias = f"شاهين {letter}{number}"
        cursor.execute("SELECT user_id FROM users WHERE alias = ?", (alias,))
        if not cursor.fetchone():
            conn.close()
            return alias

# --- القوائم الرئيسية وأزرار التفاعل ---
def get_main_menu():
    keyboard = [
        [InlineKeyboardButton("📋 تسجيل طلب جديد", callback_data="register")],
        [InlineKeyboardButton("📊 حالة الطلب / الحساب", callback_data="status")],
        [InlineKeyboardButton("📜 قوانين المجموعة", callback_data="rules")],
        [InlineKeyboardButton("🛠 التواصل مع الدعم الفني (دردشة)", callback_data="support")],
    ]
    return InlineKeyboardMarkup(keyboard)

# أمر /start للترحيب وإظهار القائمة
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if update.effective_chat.type != "private":
        return

    if user.id == ADMIN_USER_ID:
        await update.message.reply_text(
            "🛡 أهلاً بك يا مدير النظام في لوحة تحكم بوت **الشاهين**.\n\n"
            "• ستصلك طلبات التسجيل ورسائل الدعم هنا.\n"
            "• للرد على أي رسالة، قم فقط بعمل **Reply (رد)** على رسالة المستخدم واكتب ردك وسيرسله البوت إليه فوراً."
        )
        return

    await update.message.reply_text(
        f"أهلاً بك يا {user.first_name} في نظام الحماية والتحقق الخاص بمجموعة **عين الشاهين**.\n\nيرجى اختيار ما تحتاجه من القائمة أدناه:",
        reply_markup=get_main_menu(),
        parse_mode="Markdown"
    )

# معالجة الأزرار التفاعلية للقائمة الرئيسية
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = query.from_user
    data = query.data

    conn = sqlite3.connect("shahin_bot.db")
    cursor = conn.cursor()
    cursor.execute("SELECT real_name, alias, status, reject_time FROM users WHERE user_id = ?", (user.id,))
    row = cursor.fetchone()
    conn.close()

    if data == "register":
        if row and row[2] == "approved":
            await query.message.edit_text("✅ أنت مقبول مسبقاً ولديك صلاحية الوصول للمجموعة.", reply_markup=get_main_menu())
            return
        
        if row and row[2] == "pending":
            await query.message.edit_text(f"⏳ طلبك قيد المراجعة من قبل الإدارة.\nاسمك المستعار المعين: `{row[1]}`", reply_markup=get_main_menu(), parse_mode="Markdown")
            return

        if row and row[2] == "rejected" and row[3]:
            reject_time = datetime.fromisoformat(row[3])
            now = datetime.now()
            if now - reject_time < timedelta(minutes=10):
                remaining = timedelta(minutes=10) - (now - reject_time)
                mins, secs = divmod(int(remaining.total_seconds()), 60)
                await query.message.edit_text(f"❌ تم رفض طلبك سابقاً. يمكنك إعادة المحاولة بعد: {mins} دقيقة و {secs} ثانية.", reply_markup=get_main_menu())
                return

        context.user_data["waiting_for_real_name"] = True
        await query.message.edit_text("أرسل الآن **اسمك الحقيقي** (كتابة في رسالة جديدة):", parse_mode="Markdown")

    elif data == "status":
        if not row:
            await query.message.edit_text("📌 لم تقم بتقديم أي طلب تسحيل بعد.", reply_markup=get_main_menu())
        elif row[2] == "pending":
            await query.message.edit_text(f"⏳ حالة طلبك: قيد الانتظار.\nاسمك المستعار: `{row[1]}`", reply_markup=get_main_menu(), parse_mode="Markdown")
        elif row[2] == "approved":
            await query.message.edit_text(f"✅ حالة طلبك: مقبول.\nاسمك المستعار داخل المجموعة: `{row[1]}`", reply_markup=get_main_menu(), parse_mode="Markdown")
        elif row[2] == "rejected":
            await query.message.edit_text("❌ تم رفض طلبك من قبل الإدارة.", reply_markup=get_main_menu())

    elif data == "rules":
        rules_text = (
            "📜 **قوانين مجموعة عين الشاهين الآمنة:**\n\n"
            "1. ممنوع نشر أي روابط خارجية.\n"
            "2. الاحترام المتبادل وعدم الإساءة.\n"
            "3. النشر يتم حصراً عبر البوت بالاسم المستعار حفاظاً على الخصوصية."
        )
        await query.message.edit_text(rules_text, reply_markup=get_main_menu(), parse_mode="Markdown")

    elif data == "support":
        context.user_data["in_support_chat"] = True
        await query.message.edit_text(
            "💬 **أنت الآن في محادثة الدعم الفني المباشرة.**\n\n"
            "كل ما ترسله الآن سيصل للإدارة مباشرة. (للعودة للقائمة الرئيسية أرسل /menu)",
            parse_mode="Markdown"
        )

# أمر العودة للقائمة الرئيسية
async def menu_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["in_support_chat"] = False
    context.user_data["waiting_for_real_name"] = False
    await update.message.reply_text("القائمة الرئيسية:", reply_markup=get_main_menu())

# استلام الرسائل النصية للبوت
async def handle_text_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = update.message.text

    # 1. معالجة ردود المدير عبر Reply وتوجيهها للمستخدم الصحيح بدقة
    if user.id == ADMIN_USER_ID and update.effective_chat.type == "private":
        if update.message.reply_to_message:
            replied_msg = update.message.reply_to_message.text or ""
            matches = re.findall(r'\b\d{7,12}\b', replied_msg)
            if matches:
                target_user_id = int(matches[0])
                try:
                    await context.bot.send_message(
                        chat_id=target_user_id,
                        text=f"💬 **رد الإدارة:**\n{text}"
                    )
                    await update.message.reply_text("✅ تم إرسال الرد إلى المستخدم بنجاح.")
                except Exception as e:
                    await update.message.reply_text(f"❌ فشل إرسال الرد للمستخدم: {e}")
                return
            else:
                await update.message.reply_text("⚠️ لم يتم العثور على آيدي المستخدم في هذه الرسالة المردود عليها.")
                return
        return

    if update.effective_chat.type != "private":
        return

    if text == "/menu":
        await menu_command(update, context)
        return

    # 2. استقبال الاسم الحقيقي للتسجيل وتوليد الاسم المستعار
    if context.user_data.get("waiting_for_real_name"):
        context.user_data["waiting_for_real_name"] = False
        real_name = text
        alias = generate_unique_alias()

        conn = sqlite3.connect("shahin_bot.db")
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO users (user_id, real_name, alias, status, reject_time)
            VALUES (?, ?, ?, 'pending', NULL)
        """, (user.id, real_name, alias))
        conn.commit()
        conn.close()

        await update.message.reply_text(
            f"✅ تم استلام طلبك بنجاح!\nاسمك المستعار المخصص: `{alias}`\nجاري إرسال الطلب للمشرفين للمراجعة...",
            parse_mode="Markdown"
        )

        admin_keyboard = [
            [
                InlineKeyboardButton("✅ قبول", callback_data=f"adm_accept_{user.id}"),
                InlineKeyboardButton("❌ رفض", callback_data=f"adm_reject_{user.id}")
            ]
        ]
        await context.bot.send_message(
            chat_id=ADMIN_USER_ID,
            text=f"🔔 **طلب انضمام جديد:**\n\n👤 الاسم الحقيقي: {real_name}\n🏷 الاسم المستعار: `{alias}`\n🆔 الآيدي: `{user.id}`",
            reply_markup=InlineKeyboardMarkup(admin_keyboard),
            parse_mode="Markdown"
        )
        return

    # 3. محادثة الدعم الفني المباشرة
    if context.user_data.get("in_support_chat"):
        await update.message.reply_text("✅ تم إرسال رسالتك للإدارة. بانتظار الرد...")
        await context.bot.send_message(
            chat_id=ADMIN_USER_ID,
            text=f"🛠 **رسالة دعم فني جديدة:**\n\n👤 المستخدم: {user.first_name} (آيدي: `{user.id}`)\n💬 النص: {text}\n\n*(للرد، قم بعمل Reply على هذه الرسالة واكتب ردك)*",
            parse_mode="Markdown"
        )
        return

    # 4. نشر الرسائل بالاسم المستعار للأعضاء المقبولين
    conn = sqlite3.connect("shahin_bot.db")
    cursor = conn.cursor()
    cursor.execute("SELECT alias, status FROM users WHERE user_id = ?", (user.id,))
    row = cursor.fetchone()
    conn.close()

    if row and row[1] == "approved":
        alias = row[0]
        target_chat = PUBLIC_GROUP_ID if PUBLIC_GROUP_ID != 0 else ADMIN_USER_ID
        await context.bot.send_message(
            chat_id=target_chat, 
            text=f"🔹 **{alias}**: {text}",
            parse_mode="Markdown"
        )
        await update.message.reply_text("✅ تم إرسال رسالتك إلى المجموعة بنجاح.")
    else:
        await update.message.reply_text("يرجى استخدام الأزرار في القائمة أو إتمام التسجيل أولاً.", reply_markup=get_main_menu())

# --- معالجة أزرار المدير (قبول / رفض) ---
async def admin_callbacks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data.startswith("adm_accept_"):
        target_user_id = int(data.split("_")[2])
        conn = sqlite3.connect("shahin_bot.db")
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET status = 'approved' WHERE user_id = ?", (target_user_id,))
        conn.commit()
        conn.close()

        await query.edit_message_text(query.message.text + "\n\n✅ **تم قبول الطلب بنجاح.**")
        await context.bot.send_message(
            chat_id=target_user_id,
            text="🎉 مبروك! تم قبول طلبك للانضمام إلى مجموعة عين الشاهين.\n🔗 رابط المجموعة: https://t.me/YourGroupLink\n*(ملاحظة: يمكنك الآن مراسلة البوت وسيتم نشر رسائلك بالاسم المستعار)*",
            reply_markup=get_main_menu()
        )

    elif data.startswith("adm_reject_"):
        target_user_id = int(data.split("_")[2])
        reject_time = datetime.now().isoformat()

        conn = sqlite3.connect("shahin_bot.db")
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET status = 'rejected', reject_time = ? WHERE user_id = ?", (reject_time, target_user_id))
        conn.commit()
        conn.close()

        await query.edit_message_text(query.message.text + "\n\n❌ **تم رفض الطلب وتفعيل حظر الـ 10 دقائق.**")
        await context.bot.send_message(
            chat_id=target_user_id,
            text="❌ عذراً، تم رفض طلبك من قبل الإدارة. يمكنك محاولة التسجيل مجدداً بعد مرور 10 دقائق.",
            reply_markup=get_main_menu()
        )

def main():
    if BOT_TOKEN == "ضع_توكن_البوت_هنا" or ADMIN_USER_ID == 123456789:
        print("خطأ: يرجى وضع التوكن الحقيقي وآيدي المدير داخل الكود في أعلى الملف.")
        return

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("menu", menu_command))
    app.add_handler(CallbackQueryHandler(admin_callbacks, pattern="^adm_"))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), handle_text_messages))

    print("بوت الشاهين يعمل الآن بكامل طاقته واحترافيته...")
    app.run_polling()

if __name__ == "__main__":
    main()
