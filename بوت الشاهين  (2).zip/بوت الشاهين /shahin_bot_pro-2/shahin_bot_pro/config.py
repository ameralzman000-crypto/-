import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

def parse_ids(value):
    result = set()
    for item in (value or "").split(","):
        item = item.strip()
        if item.isdigit():
            result.add(int(item))
    return result

@dataclass(frozen=True)
class Settings:
    bot_token: str = os.getenv("BOT_TOKEN", "").strip()
    admin_ids: set = None
    group_id: int = int(os.getenv("TARGET_GROUP_ID", "0") or 0)
    group_link: str = os.getenv("TARGET_GROUP_LINK", "").strip()
    auto_approve: bool = os.getenv("AUTO_APPROVE", "false").lower() in ("1", "true", "yes", "on")
    auto_approve_min_name: int = int(os.getenv("AUTO_APPROVE_MIN_NAME", "3") or 3)
    web_host: str = os.getenv("WEB_HOST", "127.0.0.1").strip()
    web_port: int = int(os.getenv("WEB_PORT", "8080") or 8080)
    web_password: str = os.getenv("WEB_PASSWORD", "").strip()
    log_level: str = os.getenv("LOG_LEVEL", "INFO")

settings = Settings()
object.__setattr__(settings, "admin_ids", parse_ids(os.getenv("ADMIN_IDS", "")))
