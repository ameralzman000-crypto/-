import unittest
import tempfile
from pathlib import Path
import database

class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.original = database.DB_PATH
        database.DB_PATH = Path(self.tmp.name) / "test.db"
        database.init_db()

    def tearDown(self):
        database.DB_PATH = self.original
        self.tmp.cleanup()

    def test_user_insert_and_status(self):
        alias = database.unique_alias()
        database.upsert_pending(123, "Test User", "Test", alias)
        user = database.get_user(123)
        self.assertEqual(user["status"], "pending")
        database.set_status(123, "approved", 999)
        self.assertEqual(database.get_user(123)["status"], "approved")

    def test_counts(self):
        self.assertEqual(database.counts()["total"], 0)

if __name__ == "__main__":
    unittest.main()
