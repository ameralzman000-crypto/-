import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path(__file__).with_name("shahin_bot.db")

def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def connect():
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            telegram_name TEXT NOT NULL DEFAULT '',
            real_name TEXT NOT NULL DEFAULT '',
            alias TEXT UNIQUE,
            status TEXT NOT NULL DEFAULT 'pending'
                CHECK(status IN ('pending','approved','rejected','suspended')),
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            reject_until TEXT
        );
        CREATE TABLE IF NOT EXISTS support_tickets (
            ticket_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'open',
            created_at TEXT NOT NULL,
            closed_at TEXT,
            FOREIGN KEY(user_id) REFERENCES users(user_id)
        );
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            target_id INTEGER,
            details TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
        CREATE INDEX IF NOT EXISTS idx_tickets_status ON support_tickets(status);
        """)

def get_user(user_id):
    with connect() as db:
        row = db.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        return dict(row) if row else None

def list_users(status=None, limit=100):
    with connect() as db:
        if status:
            rows = db.execute("SELECT * FROM users WHERE status=? ORDER BY created_at DESC LIMIT ?", (status, limit)).fetchall()
        else:
            rows = db.execute("SELECT * FROM users ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

def counts():
    with connect() as db:
        total = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        return {
            "total": total,
            "pending": db.execute("SELECT COUNT(*) FROM users WHERE status='pending'").fetchone()[0],
            "approved": db.execute("SELECT COUNT(*) FROM users WHERE status='approved'").fetchone()[0],
            "rejected": db.execute("SELECT COUNT(*) FROM users WHERE status='rejected'").fetchone()[0],
            "suspended": db.execute("SELECT COUNT(*) FROM users WHERE status='suspended'").fetchone()[0],
            "tickets": db.execute("SELECT COUNT(*) FROM support_tickets WHERE status='open'").fetchone()[0],
        }

def unique_alias():
    import secrets, string
    alphabet = string.ascii_uppercase
    with connect() as db:
        for _ in range(500):
            alias = f"شاهين {secrets.choice(alphabet)}{secrets.randbelow(90)+10}"
            if not db.execute("SELECT 1 FROM users WHERE alias=?", (alias,)).fetchone():
                return alias
    raise RuntimeError("تعذر توليد اسم مستعار فريد")

def upsert_pending(user_id, telegram_name, real_name, alias):
    now = now_iso()
    with connect() as db:
        db.execute("""
        INSERT INTO users(user_id,telegram_name,real_name,alias,status,created_at,updated_at,reject_until)
        VALUES(?,?,?,?,'pending',?,?,NULL)
        ON CONFLICT(user_id) DO UPDATE SET
            telegram_name=excluded.telegram_name,
            real_name=excluded.real_name,
            alias=CASE WHEN users.alias IS NULL OR users.status='rejected' THEN excluded.alias ELSE users.alias END,
            status='pending', updated_at=excluded.updated_at, reject_until=NULL
        """, (user_id, telegram_name, real_name, alias, now, now))

def set_status(user_id, status, actor_id, details="", reject_minutes=10):
    now = now_iso()
    reject_until = None
    if status == "rejected":
        from datetime import timedelta
        reject_until = (datetime.now(timezone.utc) + timedelta(minutes=reject_minutes)).isoformat(timespec="seconds")
    with connect() as db:
        db.execute("UPDATE users SET status=?,updated_at=?,reject_until=? WHERE user_id=?",
                   (status, now, reject_until, user_id))
        db.execute("INSERT INTO audit_log(actor_id,action,target_id,details,created_at) VALUES(?,?,?,?,?)",
                   (actor_id, f"user_{status}", user_id, details, now))

def add_ticket(user_id, message):
    with connect() as db:
        cur = db.execute("INSERT INTO support_tickets(user_id,message,created_at) VALUES(?,?,?)",
                         (user_id, message, now_iso()))
        return cur.lastrowid

def audit(actor_id, action, target_id=None, details=""):
    with connect() as db:
        db.execute("INSERT INTO audit_log(actor_id,action,target_id,details,created_at) VALUES(?,?,?,?,?)",
                   (actor_id, action, target_id, details, now_iso()))

def recent_audit(limit=50):
    with connect() as db:
        rows = db.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

def search_users(term, limit=50):
    term = f"%{term}%"
    with connect() as db:
        rows = db.execute("""
        SELECT * FROM users WHERE CAST(user_id AS TEXT) LIKE ? OR real_name LIKE ? OR alias LIKE ?
        ORDER BY created_at DESC LIMIT ?
        """, (term, term, term, limit)).fetchall()
        return [dict(r) for r in rows]
