import logging
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters
)
from config import settings
from database import init_db
from handlers import (
    start, menu, admin, button_handler, registration_text,
    support_text, general_text, admin_decision, webapp_info
)
from webapp import start_web_server

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
)
log = logging.getLogger("shahin")

async def post_init(app: Application):
    await start_web_server()
    log.info("Web dashboard started on port %s", settings.web_port)

def main():
    if not settings.bot_token:
        raise SystemExit("BOT_TOKEN غير مضبوط. عدّل ملف .env أولاً.")
    if not settings.admin_ids:
        raise SystemExit("ADMIN_IDS غير مضبوط. أضف آيدي المدير في ملف .env.")
    init_db()
    app = Application.builder().token(settings.bot_token).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("menu", menu))
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(CommandHandler("web", webapp_info))
    app.add_handler(CallbackQueryHandler(admin_decision, pattern=r"^decision:"))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, registration_text), group=0)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, support_text), group=1)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, general_text), group=2)
    log.info("Shahin bot starting")
    app.run_polling(allowed_updates=["message", "callback_query", "chat_member"])

if __name__ == "__main__":
    main()
