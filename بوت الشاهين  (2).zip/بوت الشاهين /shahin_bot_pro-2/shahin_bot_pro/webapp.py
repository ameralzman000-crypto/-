import asyncio
import secrets
from aiohttp import web
from config import settings
import database as db

_runner = None

def page(body):
    return f"""<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>لوحة الشاهين</title><style>
body{{font-family:system-ui,Arial;background:#101827;color:#f3f4f6;margin:0;padding:20px}}
.wrap{{max-width:1000px;margin:auto}}h1{{color:#e8c66a}}.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px}}
.card,section{{background:#1d293b;padding:16px;border-radius:12px;margin-bottom:14px}}
.num{{font-size:26px;color:#e8c66a}}a{{color:#e8c66a}}table{{width:100%;border-collapse:collapse}}td,th{{padding:9px;border-bottom:1px solid #344256;text-align:right}}
small{{color:#cbd5e1}}input,button{{padding:10px;border-radius:8px;border:0}}button{{background:#e8c66a;cursor:pointer}}
</style></head><body><div class="wrap">{body}</div></body></html>"""

def auth_ok(request):
    expected = settings.web_password
    if not expected:
        return False
    supplied = request.headers.get("X-Dashboard-Password", "")
    if not supplied:
        supplied = request.query.get("password", "")
    return secrets.compare_digest(supplied, expected)

async def dashboard(request):
    if not auth_ok(request):
        return web.Response(text=page("""
<h1>🛡 لوحة الشاهين</h1><section><p>أدخل كلمة مرور لوحة الإدارة.</p>
<form method="get"><input type="password" name="password" placeholder="كلمة المرور" required>
<button>دخول</button></form></section><small>لا تشارك كلمة المرور. استخدم اللوحة محلياً فقط ما لم تضف HTTPS.</small>
"""), content_type="text/html", status=401)
    c = db.counts()
    users = db.list_users(limit=100)
    rows = "".join(
        f"<tr><td>{r['user_id']}</td><td>{esc(r['real_name'])}</td><td>{esc(r['alias'] or '')}</td><td>{esc(r['status'])}</td><td>{esc(r['updated_at'])}</td></tr>"
        for r in users
    )
    body = f"""<h1>🛡 لوحة إدارة الشاهين</h1><p>لوحة محلية محمية بكلمة مرور</p>
<div class="cards">{''.join(f'<div class="card"><small>{label}</small><div class="num">{value}</div></div>' for label,value in [('كل الأعضاء',c['total']),('مقبولون',c['approved']),('معلقون',c['pending']),('مرفوضون',c['rejected']),('موقوفون',c['suspended']),('تذاكر مفتوحة',c['tickets'])])}</div>
<section><h2>آخر 100 عضو</h2><table><thead><tr><th>آيدي</th><th>الاسم</th><th>المستعار</th><th>الحالة</th><th>آخر تحديث</th></tr></thead><tbody>{rows}</tbody></table></section>
<section><a href="/health">فحص الخدمة</a> | <a href="/">تحديث الصفحة</a></section>"""
    return web.Response(text=page(body), content_type="text/html")

def esc(value):
    import html
    return html.escape(str(value or ""))

async def health(request):
    return web.json_response({"ok": True, "service": "shahin-dashboard"})

async def start_web_server():
    global _runner
    if _runner:
        return
    app = web.Application()
    app.router.add_get("/", dashboard)
    app.router.add_get("/health", health)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, settings.web_host, settings.web_port)
    try:
        await site.start()
        _runner = runner
    except OSError:
        # Dashboard is optional if port is already used.
        await runner.cleanup()
        raise
